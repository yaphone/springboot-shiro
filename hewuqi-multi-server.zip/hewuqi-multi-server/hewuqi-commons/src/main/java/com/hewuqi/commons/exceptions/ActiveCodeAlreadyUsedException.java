package com.hewuqi.commons.exceptions;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 15:52
 */
public class ActiveCodeAlreadyUsedException extends Exception{
    public ActiveCodeAlreadyUsedException() {
        super("验证码已使用");
    }
}
