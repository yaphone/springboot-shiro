package com.hewuqi.commons.enums;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/26 21:38
 */
public enum UserStatusEnum {
    UN_ACTIVE(0, "未激活"),
    ACTIVE(1, "激活"),
    UN_LOCKED(0, "未锁定"),
    LOCKED(1, "锁定");

    int code;
    String msg;

    UserStatusEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
