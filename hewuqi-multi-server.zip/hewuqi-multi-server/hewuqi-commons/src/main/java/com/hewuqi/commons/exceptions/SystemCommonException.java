package com.hewuqi.commons.exceptions;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/5 0:24
 */
public class SystemCommonException extends Exception{
    public SystemCommonException() {
        super("系统内部错误");
    }
}
