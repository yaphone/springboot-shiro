package com.hewuqi.commons.exceptions;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/26 23:25
 */
public class UserAlreadyExistException extends Exception {
    public UserAlreadyExistException() {
        super("用户已存在");
    }
}
