package com.hewuqi.commons.exceptions;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 23:59
 */
public class InvalidActiveCodeException extends Exception {
    public InvalidActiveCodeException() {
        super("激活码无效");
    }
}
