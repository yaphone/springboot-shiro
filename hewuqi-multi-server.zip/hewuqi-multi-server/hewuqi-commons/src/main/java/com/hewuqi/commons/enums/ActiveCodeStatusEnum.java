package com.hewuqi.commons.enums;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 16:02
 */
public enum ActiveCodeStatusEnum {

    INVAILD(1, "已使用"),
    AVAILD(0, "未使用");

    private int code;
    private String msg;
    ActiveCodeStatusEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
