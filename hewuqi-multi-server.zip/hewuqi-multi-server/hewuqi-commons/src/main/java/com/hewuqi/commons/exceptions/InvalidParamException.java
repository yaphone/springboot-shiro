package com.hewuqi.commons.exceptions;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 23:51
 */
public class InvalidParamException extends Exception {
    public InvalidParamException() {
        super("参数不合法");
    }
}
