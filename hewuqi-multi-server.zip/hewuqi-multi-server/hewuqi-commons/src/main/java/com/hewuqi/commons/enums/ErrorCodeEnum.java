package com.hewuqi.commons.enums;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/5 17:23
 */
public enum ErrorCodeEnum {
    SUCCESS(200, "success"),

    //权限相关
    UN_LOGIN(601, "未登陆"),
    UN_AUTH(602, "未认证"),
    UNKOWN_ACCOUNT(603, "未知账户"),
    NO_PERMISSION(604, "无权限"),
    ACCOUNT_UNACTIVE(605, "账号未激活"),
    ACCOUNT_LOCKED(606, "账号被锁定"),
    WRONG_TOKEN(607, "用户名或密码错误"),
    USER_ALREADY_EXIST(608, "用户已存在"),
    USER_NOT_EXIST(609, "用户不存在"),

    INVALID_PARAM(701, "参数不合法"),
    INVALID_ACTIVE_CODE(702, "激活码无效"),
    INVALID_ACTIVE_CODE_VERIFY(703, "激活验证码无效"),
    SYSTEM_COMMON_EXCEPTION(704, "系统内部错误");

    int code;
    String msg;

    ErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
