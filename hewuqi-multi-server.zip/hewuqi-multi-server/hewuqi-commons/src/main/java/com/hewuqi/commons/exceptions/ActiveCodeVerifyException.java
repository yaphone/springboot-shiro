package com.hewuqi.commons.exceptions;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 16:48
 */
public class ActiveCodeVerifyException extends Exception {
    public ActiveCodeVerifyException() {
        super("较验失败");
    }
}
