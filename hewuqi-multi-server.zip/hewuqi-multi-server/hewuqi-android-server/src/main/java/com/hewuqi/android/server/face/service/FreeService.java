package com.hewuqi.android.server.face.service;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/6/2 21:44
 */
public interface FreeService {

}
