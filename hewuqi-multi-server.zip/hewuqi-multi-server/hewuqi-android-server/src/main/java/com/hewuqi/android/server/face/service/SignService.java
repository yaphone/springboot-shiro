package com.hewuqi.android.server.face.service;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/5/13 16:53
 */
public interface SignService {
    String generateSign();
}
