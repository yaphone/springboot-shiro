package com.hewuqi.android.server.free.controller;

import com.hewuqi.android.server.free.dto.*;
import com.hewuqi.android.server.free.service.FreeService;
import com.hewuqi.commons.enums.ErrorCodeEnum;
import com.hewuqi.commons.responses.BaseResponse;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/6/2 23:15
 */
@RestController
@RequestMapping("free")
public class FreeController {
    @Autowired
    private FreeService freeService;

    @RequestMapping("ipSearch")
    @RequiresPermissions("ip:search")
    public BaseResponse ipSearch(String ip) {
        IpDto resp = freeService.getIpDto(ip);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, resp);
    }

    @RequestMapping("cellSearch")
    @RequiresPermissions("call:search")
    public BaseResponse cellSearch(String mnc, String lac, String ci) {
        CellDto resp = freeService.getCellDto(mnc, lac, ci);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, resp);
    }

    @RequestMapping("bankCardSearch")
    @RequiresPermissions("bankCard:search")
    public BaseResponse bankCardSearch(String cardNo) {
        BankCardDto cardDto = freeService.getBankCardDto(cardNo);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, cardDto);
    }

    @RequestMapping("macSearch")
    @RequiresPermissions("mac:search")
    public BaseResponse macSearch(String mac) {
        MacDto macDto = freeService.getMacDto(mac);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, macDto);
    }

    @RequestMapping("whoisSearch")
    @RequiresPermissions("whois:search")
    public BaseResponse whoisSearch(String address) {
        WhoisDto whoisDto = freeService.getWhoisDto(address);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, whoisDto);
    }
}
