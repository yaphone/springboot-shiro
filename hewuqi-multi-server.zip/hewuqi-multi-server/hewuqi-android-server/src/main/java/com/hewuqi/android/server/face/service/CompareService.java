package com.hewuqi.android.server.face.service;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/5/30 21:05
 */
public interface CompareService {
    String getCompareResult(String urlA, String urlB);
}
