package com.hewuqi.android.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/21 23:51
 */
@SpringBootApplication(scanBasePackages = {"com.hewuqi.*"})
public class AndroidServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AndroidServerApplication.class, args);
    }
}
