package com.hewuqi.android.server.face.service;

/**
 * 腾讯云存储
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/5/14 21:02
 */
public interface QiNiuStorageService {
    String genUpToken();
}
