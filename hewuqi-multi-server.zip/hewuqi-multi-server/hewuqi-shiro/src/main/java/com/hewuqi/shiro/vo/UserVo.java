package com.hewuqi.shiro.vo;

import lombok.Data;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 17:29
 */
@Data
public class UserVo {
    private String username;
    private String password;
}
