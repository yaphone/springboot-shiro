package com.hewuqi.shiro.util;

import org.apache.shiro.crypto.hash.SimpleHash;

import java.util.Random;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 22:32
 */
public class ActiveCodeUtil {

    private static String SALT = "hewuqi";

    /**
     * 生成激活码，生成规则如下：
     * 取unix时间戳（ms）,salt(hewuqi)，hash三次，分别取第3、7、10、14位，最前面加1000~9999的随机值
     * @return
     */
    public static String generateActiveCode() {
        Random random = new Random();
        int head = random.nextInt(9000) + 1000;
        long time = System.currentTimeMillis();
        String hashStr = new SimpleHash("MD5", time + "", SALT, 3).toString();
        String hash = hashStr.substring(2, 3) + hashStr.substring(6, 7) + hashStr.substring(9, 10) + hashStr.substring(13, 14);

        return head + hash.toUpperCase();
    }

    public static void main(String[] args) {
        String activeCode = generateActiveCode();
        System.out.println(activeCode);
    }
}
