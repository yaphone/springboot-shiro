package com.hewuqi.shiro.service;


import com.hewuqi.shiro.dto.SessionDto;
import com.hewuqi.shiro.model.custom.UserInfo;

import java.util.List;
import java.util.Map;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/5 18:23
 */
public interface BaseService{
    /**
     * 用户注册
     * @param params
     * @return
     * @throws Exception
     */
    boolean regist(Map<String, String> params) throws Exception;

    /**
     * 获取Session
     * @param username
     * @param inPassword
     * @return
     */
    SessionDto login(String username, String inPassword);

    /**
     * 获取用户信息
     * @return
     */
    List<UserInfo> getAllUsers();

    /**
     * 根据用户名获取用户信息
     * @param username
     * @return
     */
    UserInfo getUserinfoByUsername(String username) throws Exception;
    /**
     * 用户认证，完善真实姓名，核武ID，认证码
     * @return
     */
    boolean identificateUser(Map<String, String> params) throws Exception;
}
