package com.hewuqi.shiro.service.impl;

import com.hewuqi.commons.exceptions.UserNotExistException;
import com.hewuqi.shiro.dao.UserDetailMapper;
import com.hewuqi.shiro.dao.custom.UserInfoMapper;
import com.hewuqi.shiro.model.User;
import com.hewuqi.shiro.model.UserDetail;
import com.hewuqi.shiro.model.UserDetailExample;
import com.hewuqi.shiro.model.custom.UserInfo;
import com.hewuqi.shiro.service.UserInfoService;
import com.hewuqi.shiro.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 22:52
 */
@Service
public class UserInfoServiceImpl implements UserInfoService{

    @Autowired
    private UserInfoMapper userInfoMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private UserDetailMapper userDetailMapper;

    @Override
    public List<UserInfo> getAllUserInfo() {
        return userInfoMapper.selectAllUserInfo(new HashMap<>());
    }

    @Override
    public UserInfo getUserinfoByUsername(String username) throws Exception{
        User user = userService.getUserByUsername(username);
        if (user == null) {
            throw new UserNotExistException();
        }
        UserDetailExample detailExample = new UserDetailExample();
        detailExample.createCriteria().andUserIdEqualTo(user.getId());
        List<UserDetail> details = userDetailMapper.selectByExample(detailExample);
        if (details.size() == 0) {
            throw new UserNotExistException();
        }
        UserDetail detail = details.get(0);

        UserInfo userInfo = new UserInfo();
        userInfo.setUsername(user.getUsername());
        userInfo.setHwid(detail.getHwid());
        userInfo.setEmail(detail.getEmail());
        userInfo.setPhoneNum(detail.getPhoneNum());
        userInfo.setQqNum(detail.getQq());
        userInfo.setRealName(detail.getRealName());
        userInfo.setOutDate(new Date());
        userInfo.setActive(user.getActive());

        return userInfo;
    }
}
