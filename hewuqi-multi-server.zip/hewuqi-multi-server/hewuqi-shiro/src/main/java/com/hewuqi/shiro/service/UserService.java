package com.hewuqi.shiro.service;


import com.hewuqi.shiro.model.User;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 15:04
 */
public interface UserService {
    User getUserByUsername(String username);
    boolean addUser(User user);
    boolean isUserExist(String username);
    int updateUser(User user);
}
