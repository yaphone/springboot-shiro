package com.hewuqi.shiro.service.impl;

import com.hewuqi.shiro.dao.PermissionMapper;
import com.hewuqi.shiro.model.Permission;
import com.hewuqi.shiro.model.PermissionExample;
import com.hewuqi.shiro.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 16:25
 */
@Service
public class PermissionServiceImpl implements PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;

    @Override
    public List<Permission> getPermissionByPermissionId(long permissionId) {
        PermissionExample example = new PermissionExample();
        example.createCriteria().andIdEqualTo(permissionId);
        List<Permission> permissions = permissionMapper.selectByExample(example);
        return permissions;
    }

    @Override
    public int insertPermission(Permission permission) {
        return permissionMapper.insert(permission);
    }
}
