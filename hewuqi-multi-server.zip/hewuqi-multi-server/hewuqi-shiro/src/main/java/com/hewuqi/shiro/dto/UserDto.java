package com.hewuqi.shiro.dto;

import com.hewuqi.shiro.model.User;
import lombok.Data;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 22:14
 */
@Data
public class UserDto {
    private User user;
    private UserDto userDetail;
}
