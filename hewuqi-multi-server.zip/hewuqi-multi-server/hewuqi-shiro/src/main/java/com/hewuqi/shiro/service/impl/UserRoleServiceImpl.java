package com.hewuqi.shiro.service.impl;


import com.hewuqi.shiro.dao.UserRoleMapper;
import com.hewuqi.shiro.model.Role;
import com.hewuqi.shiro.model.User;
import com.hewuqi.shiro.model.UserRole;
import com.hewuqi.shiro.model.UserRoleExample;
import com.hewuqi.shiro.service.RoleService;
import com.hewuqi.shiro.service.UserRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 16:03
 */
@Service
public class UserRoleServiceImpl implements UserRoleService {

    @Autowired
    private UserRoleMapper userRoleMapper;
    @Autowired
    private RoleService roleService;

    @Override
    public List<Role> getRolesByUser(User user) {
        List<Role> roles = new ArrayList<>();
        UserRoleExample example = new UserRoleExample();
        example.createCriteria().andUserIdEqualTo(user.getId());
        List<UserRole> userRoles = userRoleMapper.selectByExample(example);
        for (UserRole userRole: userRoles) {
            roles.add(roleService.getRoleByRoleId(userRole.getRoleId()));
        }
        return roles;
    }

    @Override
    public int insertUserRole(UserRole userRole) {
        return userRoleMapper.insert(userRole);
    }

    @Override
    public int updateUserRole(UserRole userRole) {
        return userRoleMapper.updateByPrimaryKeySelective(userRole);
    }

    @Override
    public List<UserRole> getUserRoleByExample(UserRoleExample example) {
        return userRoleMapper.selectByExample(example);
    }
}
