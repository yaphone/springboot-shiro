package com.hewuqi.shiro.dao.custom;

import com.hewuqi.shiro.model.custom.UserInfo;

import java.util.List;
import java.util.Map;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 22:34
 */
public interface UserInfoMapper {
    List<UserInfo> selectAllUserInfo(Map<String, String> params);
}
