package com.hewuqi.shiro.framework.spring;


import com.hewuqi.commons.enums.ErrorCodeEnum;
import com.hewuqi.commons.exceptions.*;
import com.hewuqi.commons.responses.BaseResponse;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authz.UnauthenticatedException;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/19 23:17
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 无权限
     * @return
     */
    @ExceptionHandler(value = UnauthorizedException.class)
    public BaseResponse unauthorizedException() {
        return new BaseResponse(ErrorCodeEnum.NO_PERMISSION, new HashMap<>());
    }

    /**
     * 未认证
     * @return
     */
    @ExceptionHandler(value = UnauthenticatedException.class)
    public BaseResponse unauthenticatedException() {
        return new BaseResponse(ErrorCodeEnum.UN_LOGIN, new HashMap<>());
    }

    /**
     * 未知账号
     * @return
     */
    @ExceptionHandler(value = UnknownAccountException.class)
    public BaseResponse unknownAccountException() {
        return new BaseResponse(ErrorCodeEnum.UNKOWN_ACCOUNT, new HashMap<>());
    }

    /**
     * 账号未激活
     * @return
     */
    @ExceptionHandler(value = DisabledAccountException.class)
    public BaseResponse disabledAccountException() {
        return new BaseResponse(ErrorCodeEnum.ACCOUNT_UNACTIVE, new HashMap<>());
    }

    /**
     * 账号被锁定
     * @return
     */
    @ExceptionHandler(value = LockedAccountException.class)
    public BaseResponse lockedAccountException() {
        return new BaseResponse(ErrorCodeEnum.ACCOUNT_LOCKED, new HashMap<>());
    }

    @ExceptionHandler(value = IncorrectCredentialsException.class)
    public BaseResponse incorrectCredentialsException() {
        return new BaseResponse(ErrorCodeEnum.WRONG_TOKEN, new HashMap<>());
    }

    @ExceptionHandler(value = UserAlreadyExistException.class)
    public BaseResponse userAlreadyExistException() {
        return new BaseResponse(ErrorCodeEnum.USER_ALREADY_EXIST, new HashMap<>());
    }

    @ExceptionHandler(value = UserNotExistException.class)
    public BaseResponse userNotExistException() {
        return new BaseResponse(ErrorCodeEnum.USER_NOT_EXIST, new HashMap<>());
    }

    /**
     * 参数不合法
     * @return
     */
    @ExceptionHandler(value = InvalidParamException.class)
    public BaseResponse paramInvaildException() {
        return new BaseResponse(ErrorCodeEnum.INVALID_PARAM, new HashMap<>());
    }

    /**
     * 激活码无效
     * @return
     */
    @ExceptionHandler(value = InvalidActiveCodeException.class)
    public BaseResponse VerifyCodeInvalidException() {
        return new BaseResponse(ErrorCodeEnum.INVALID_ACTIVE_CODE, new HashMap<>());
    }

    /**
     * 激活验证码无效
     * @return
     */
    @ExceptionHandler(value = ActiveCodeVerifyException.class)
    public BaseResponse activeCodeVerifyException() {
        return new BaseResponse(ErrorCodeEnum.INVALID_ACTIVE_CODE_VERIFY, new HashMap<>());
    }

    /**
     * 系统内部错误
     * @return
     */
    @ExceptionHandler(value = SystemCommonException.class)
    public BaseResponse systemCommonException() {
        return new BaseResponse(ErrorCodeEnum.SYSTEM_COMMON_EXCEPTION, new HashMap<>());
    }
}
