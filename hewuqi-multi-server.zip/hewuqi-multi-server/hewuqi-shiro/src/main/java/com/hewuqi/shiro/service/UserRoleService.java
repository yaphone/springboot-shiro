package com.hewuqi.shiro.service;

import com.hewuqi.shiro.model.Role;
import com.hewuqi.shiro.model.User;
import com.hewuqi.shiro.model.UserRole;
import com.hewuqi.shiro.model.UserRoleExample;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 16:02
 */
public interface UserRoleService {
    List<Role> getRolesByUser(User user);
    int insertUserRole(UserRole userRole);
    int updateUserRole(UserRole userRole);
    List<UserRole> getUserRoleByExample(UserRoleExample example);
}
