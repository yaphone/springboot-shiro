package com.hewuqi.shiro.model.custom;

import lombok.Data;

import java.util.Date;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 22:35
 */
@Data
public class UserInfo {
    private Long id;

    private String username;

    private Integer active;

    private Integer locked;

    private Date createTime;

    private Long detailId;

    private String email;

    private String phoneNum;

    /**
     * 核武ID
     */
    private String hwid;

    private String qqNum;

    private String realName;

    /**
     * 过期时间
     */
    private Date outDate;
}
