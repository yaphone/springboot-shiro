package com.hewuqi.shiro.service;

import com.hewuqi.commons.exceptions.InvalidActiveCodeException;
import com.hewuqi.shiro.model.ActiveCode;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 15:54
 */
public interface ActiveCodeService {
    ActiveCode getActiveCodeByString(String activeCode) throws InvalidActiveCodeException;
    int insertActiveCode(ActiveCode activeCode);
    int updateActiveCode(ActiveCode activeCode);
}
