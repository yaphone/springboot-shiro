package com.hewuqi.shiro.service.impl;


import com.hewuqi.shiro.dao.RolePermissionMapper;
import com.hewuqi.shiro.model.Permission;
import com.hewuqi.shiro.model.Role;
import com.hewuqi.shiro.model.RolePermission;
import com.hewuqi.shiro.model.RolePermissionExample;
import com.hewuqi.shiro.service.PermissionService;
import com.hewuqi.shiro.service.RolePermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 16:29
 */
@Service
public class RolePermissionServiceImpl implements RolePermissionService {

    @Autowired
    private PermissionService permissionService;
    @Autowired
    private RolePermissionMapper rolePermissionMapper;

    @Override
    public List<Permission> getPermissionsByRole(Role role) {
        List<Permission> permissions = new ArrayList<>();
        RolePermissionExample example = new RolePermissionExample();
        example.createCriteria().andRoleIdEqualTo(role.getId());
        List<RolePermission> rolePermissions = rolePermissionMapper.selectByExample(example);
        for (RolePermission rolePermission: rolePermissions) {
            permissions.addAll(permissionService.getPermissionByPermissionId(rolePermission.getPermissionId()));
        }
        return permissions;
    }
}
