package com.hewuqi.shiro.util;

import org.apache.shiro.crypto.hash.SimpleHash;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 16:28
 */
public class CommonUtil {
    private static String SALT = "hweuqi";
    /**
     * 核武器激活时较验验证码, 较验规则：Hash(activeCode + hwid + salt) 取第1、4、7、10位 = verifyCode
     * 目前salt固定值为： hewuqi
     * @param activeCode
     * @param hwid
     * @param verifyCode
     * @return
     */
    public static boolean checkVerifyCode(String activeCode, String hwid, String verifyCode) {
        String ret = generateVerifyCode(activeCode, hwid);
        return ret.equals(verifyCode);
    }

    /**
     * 生成verifyCode
     * @param activeCode
     * @param hwid
     * @return
     */
    public static String generateVerifyCode(String activeCode, String hwid) {
        String hashStr = new SimpleHash("MD5", activeCode, hwid + SALT).toString();
        String verifyCode = hashStr.substring(0, 1) + hashStr.substring(3, 4) + hashStr.substring(6, 7) + hashStr.substring(9, 10);
        return verifyCode.toUpperCase();
    }

    public static void main(String[] args) {
        String activeCode = "1327AA6A";
        String hwid = "100001";
        String verifyCode = generateVerifyCode(activeCode, hwid);

        System.out.println(verifyCode);

        boolean checkRet = checkVerifyCode(activeCode, hwid, verifyCode);
        System.out.println(checkRet);
    }
}
