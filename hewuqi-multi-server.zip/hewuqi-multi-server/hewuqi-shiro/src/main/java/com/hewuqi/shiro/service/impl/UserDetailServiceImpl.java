package com.hewuqi.shiro.service.impl;

import com.hewuqi.commons.exceptions.SystemCommonException;
import com.hewuqi.shiro.dao.UserDetailMapper;
import com.hewuqi.shiro.model.UserDetail;
import com.hewuqi.shiro.model.UserDetailExample;
import com.hewuqi.shiro.service.UserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 21:00
 */
@Service
public class UserDetailServiceImpl implements UserDetailService {

    @Autowired
    private UserDetailMapper userDetailMapper;

    @Override
    public void insertUserDetail(UserDetail userDetail) {
        userDetailMapper.insert(userDetail);
    }

    @Override
    public long getDetailIdByUserId(long userId) throws Exception{
        UserDetailExample example = new UserDetailExample();
        example.createCriteria().andUserIdEqualTo(userId);
        List<UserDetail> userDetails = userDetailMapper.selectByExample(example);
        if(userDetails.size() != 1) {
            throw new SystemCommonException();
        }
        return userDetails.get(0).getId();
    }

    @Override
    public int updateUserDetail(UserDetail userDetail) {
        return userDetailMapper.updateByPrimaryKeySelective(userDetail);
    }
}
