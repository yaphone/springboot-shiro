package com.hewuqi.shiro.dao;

import com.hewuqi.shiro.model.ActiveCode;
import com.hewuqi.shiro.model.ActiveCodeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ActiveCodeMapper {
    long countByExample(ActiveCodeExample example);

    int deleteByExample(ActiveCodeExample example);

    int deleteByPrimaryKey(Long id);

    int insert(ActiveCode record);

    int insertSelective(ActiveCode record);

    List<ActiveCode> selectByExample(ActiveCodeExample example);

    ActiveCode selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") ActiveCode record, @Param("example") ActiveCodeExample example);

    int updateByExample(@Param("record") ActiveCode record, @Param("example") ActiveCodeExample example);

    int updateByPrimaryKeySelective(ActiveCode record);

    int updateByPrimaryKey(ActiveCode record);
}