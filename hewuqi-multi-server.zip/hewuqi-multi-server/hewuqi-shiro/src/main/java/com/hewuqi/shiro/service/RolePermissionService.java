package com.hewuqi.shiro.service;


import com.hewuqi.shiro.model.Permission;
import com.hewuqi.shiro.model.Role;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 16:28
 */
public interface RolePermissionService {
    List<Permission> getPermissionsByRole(Role role);
}
