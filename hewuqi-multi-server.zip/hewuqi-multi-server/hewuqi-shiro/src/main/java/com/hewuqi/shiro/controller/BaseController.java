package com.hewuqi.shiro.controller;

import com.hewuqi.commons.enums.ErrorCodeEnum;
import com.hewuqi.commons.responses.BaseResponse;
import com.hewuqi.shiro.dto.SessionDto;
import com.hewuqi.shiro.model.custom.UserInfo;
import com.hewuqi.shiro.service.BaseService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/5 16:37
 */
@RestController
@RequestMapping("base")
public class BaseController {

    @Autowired
    private BaseService baseService;


    @RequestMapping(value = "login", method = RequestMethod.POST)
    public BaseResponse login(@RequestBody Map<String, String> params) {

        String username = params.get("username");
        String password = params.get("password");

        SessionDto sessionDto = baseService.login(username, password);

        return new BaseResponse(ErrorCodeEnum.SUCCESS, sessionDto);
    }

    @RequestMapping(value = "regist", method = RequestMethod.POST)
    public BaseResponse regist(@RequestBody Map<String, String> params) throws Exception{

        Map<String, Boolean> resultMap = new HashMap<>();
        boolean result = baseService.regist(params);
        resultMap.put("result", result);

        return new BaseResponse(ErrorCodeEnum.SUCCESS, resultMap);
    }

    @RequestMapping(value = "user/info", method = RequestMethod.GET)
    public BaseResponse getAllUser() {
        List<UserInfo> userInfos = baseService.getAllUsers();
        return new BaseResponse(ErrorCodeEnum.SUCCESS, userInfos);
    }

    @RequestMapping("needLogin")
    public BaseResponse login() {
        return new BaseResponse(ErrorCodeEnum.UN_LOGIN, "you have to login before use this service");
    }

    @RequestMapping(value = "user/detail", method = RequestMethod.GET)
    public BaseResponse getUserDetail(@PathParam("username") String username) throws Exception {
        UserInfo userInfo = baseService.getUserinfoByUsername(username);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, userInfo);
    }

    /**
     * 用户认证，完善真实姓名，核武ID，认证码
     * @return
     */
    @RequestMapping(value = "user/auth", method = RequestMethod.POST)
    @RequiresPermissions("user:auth")
    public BaseResponse identificateUser(@RequestBody Map<String, String> params) throws Exception {
        Map<String, Boolean> retMap = new HashMap<>();
        boolean ret = baseService.identificateUser(params);
        retMap.put("result", ret);
        return new BaseResponse(ErrorCodeEnum.SUCCESS, retMap);
    }
}
