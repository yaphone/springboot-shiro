package com.hewuqi.shiro.service.impl;

import com.hewuqi.commons.enums.ActiveCodeStatusEnum;
import com.hewuqi.commons.exceptions.InvalidActiveCodeException;
import com.hewuqi.shiro.dao.ActiveCodeMapper;
import com.hewuqi.shiro.model.ActiveCode;
import com.hewuqi.shiro.model.ActiveCodeExample;
import com.hewuqi.shiro.service.ActiveCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 15:55
 */
@Service
public class ActiveCodeServiceImpl implements ActiveCodeService {

    @Autowired
    private ActiveCodeMapper activeCodeMapper;

    @Override
    public ActiveCode getActiveCodeByString(String activeCodeStr) throws InvalidActiveCodeException {
        ActiveCodeExample example = new ActiveCodeExample();
        example.createCriteria().andActiveCodeEqualTo(activeCodeStr).andStatusEqualTo(ActiveCodeStatusEnum.AVAILD.getCode());
        List<ActiveCode> activeCodes = activeCodeMapper.selectByExample(example);
        if(activeCodes.size() != 1) {
            throw new InvalidActiveCodeException();
        }
        ActiveCode activeCode = activeCodes.get(0);
        //较验activeCode是否已使用
        if(activeCode.getStatus().equals(ActiveCodeStatusEnum.INVAILD.getCode())) {
            throw new InvalidActiveCodeException();
        }
        return activeCode;
    }

    @Override
    public int insertActiveCode(ActiveCode activeCode) {
        return activeCodeMapper.insert(activeCode);
    }

    @Override
    public int updateActiveCode(ActiveCode activeCode) {
        return activeCodeMapper.updateByPrimaryKeySelective(activeCode);
    }
}
