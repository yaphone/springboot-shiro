package com.hewuqi.shiro.service;

import com.hewuqi.shiro.model.custom.UserInfo;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 22:51
 */
public interface UserInfoService {
    List<UserInfo> getAllUserInfo();
    UserInfo getUserinfoByUsername(String username) throws Exception;
}
