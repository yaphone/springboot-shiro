package com.hewuqi.shiro.service;

import com.hewuqi.shiro.model.UserDetail;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/31 20:58
 */
public interface UserDetailService {
    void insertUserDetail(UserDetail userDetail);
    long getDetailIdByUserId(long userId) throws Exception;
    int updateUserDetail(UserDetail userDetail);
}
