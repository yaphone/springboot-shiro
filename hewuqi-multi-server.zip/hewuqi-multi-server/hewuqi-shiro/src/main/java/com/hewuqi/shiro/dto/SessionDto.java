package com.hewuqi.shiro.dto;

import lombok.Data;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/22 21:23
 */
@Data
public class SessionDto {

    private String sessionId;
}
