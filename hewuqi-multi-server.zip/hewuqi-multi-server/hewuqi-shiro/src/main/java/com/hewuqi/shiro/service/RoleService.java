package com.hewuqi.shiro.service;


import com.hewuqi.shiro.model.Role;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 15:45
 */
public interface RoleService {
    Role getRoleByRoleId(long roleId);
    int insertRole(Role role);
    long getRoleIdByRoleName(String roleName);
}
