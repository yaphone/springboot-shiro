package com.hewuqi.shiro.util.enums;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/5 22:57
 */
public enum RoleIdEnum {

    ADMIN(1L, "管理员"),
    UNAUTH(2L, "未认证"),
    PRIMARY(3L, "基础用户");

    private long roleId;
    private String msg;
    RoleIdEnum(long roleId, String msg) {
        this.roleId = roleId;
        this.msg = msg;
    }

    public long getRoleId() {
        return roleId;
    }

    public String getMsg() {
        return msg;
    }

}
