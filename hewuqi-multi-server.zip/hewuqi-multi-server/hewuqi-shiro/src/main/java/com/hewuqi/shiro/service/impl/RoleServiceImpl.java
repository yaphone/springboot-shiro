package com.hewuqi.shiro.service.impl;

import com.hewuqi.shiro.dao.RoleMapper;
import com.hewuqi.shiro.model.Role;
import com.hewuqi.shiro.model.RoleExample;
import com.hewuqi.shiro.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/7 15:46
 */
@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleMapper roleMapper;


    @Override
    public Role getRoleByRoleId(long roleId) {
        RoleExample example = new RoleExample();
        example.createCriteria().andIdEqualTo(roleId);
        List<Role> roles = roleMapper.selectByExample(example);
        return roles.size() == 1 ? roles.get(0) : null;
    }

    @Override
    public int insertRole(Role role) {
        return roleMapper.insert(role);
    }

    @Override
    public long getRoleIdByRoleName(String roleName) {
        RoleExample example = new RoleExample();
        example.createCriteria().andRoleNameEqualTo(roleName);
        List<Role> roles = roleMapper.selectByExample(example);
        if (roles.size() != 1) {
            return 0;
        }
        return roles.get(0).getId();
    }
}
