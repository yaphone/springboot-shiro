package com.hewuqi.shiro.service.impl;

import com.hewuqi.commons.enums.ActiveCodeStatusEnum;
import com.hewuqi.commons.enums.UserStatusEnum;
import com.hewuqi.commons.exceptions.ActiveCodeVerifyException;
import com.hewuqi.commons.exceptions.InvalidParamException;
import com.hewuqi.commons.exceptions.SystemCommonException;
import com.hewuqi.commons.exceptions.UserAlreadyExistException;
import com.hewuqi.commons.utils.IdWorker;
import com.hewuqi.shiro.dto.SessionDto;
import com.hewuqi.shiro.model.*;
import com.hewuqi.shiro.model.custom.UserInfo;
import com.hewuqi.shiro.service.*;
import com.hewuqi.shiro.util.CommonUtil;
import com.hewuqi.shiro.util.enums.RoleIdEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/10/5 18:23
 */
@Service
public class BaseServiceImpl implements BaseService {

    @Autowired
    private UserService userService;
    @Autowired
    private UserDetailService userDetailService;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private ActiveCodeService activeCodeService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private UserRoleService userRoleService;

    private static IdWorker idWorker = new IdWorker(1L, 1L);
    private static final String UNAUTH = "unauth";

    @Override
    public boolean regist(Map<String, String> params) throws Exception{

        String username = params.get("username");
        String inPassword = params.get("password");

        //TODO 先较验用户名是否重复
        if (userService.isUserExist(username)) {
            throw new UserAlreadyExistException();
        }

        User user = new User();
        long userId = idWorker.nextId();
        user.setId(userId);
        user.setUsername(username);
        user.setActive(UserStatusEnum.UN_ACTIVE.getCode());
        user.setLocked(UserStatusEnum.UN_LOCKED.getCode());
        user.setCreateTime(new Date());

        //生成盐值
        String salt = new SecureRandomNumberGenerator().nextBytes().toHex();
        user.setSalt(salt);

        //将原始密码加盐（上面生成的盐），并且用md5算法加密三次，将最后结果存入数据库中
        String password = new SimpleHash("MD5", inPassword, salt, 3).toString();
        user.setPassword(password);

        // 邮箱，手机号
        String email = params.get("email");
        String phoneNum = params.get("phoneNum");
        String qq = params.get("qqNum");
        UserDetail userDetail = new UserDetail();
        userDetail.setId(idWorker.nextId());
        userDetail.setUserId(userId);
        userDetail.setEmail(email);
        userDetail.setPhoneNum(phoneNum);
        userDetail.setQq(qq);
        userDetailService.insertUserDetail(userDetail);

        userService.addUser(user);

        // 为添加角色
        UserRole userRole = new UserRole();
        userRole.setId(idWorker.nextId());
        userRole.setUserId(userId);
        long roleId = roleService.getRoleIdByRoleName(UNAUTH);
        userRole.setRoleId(roleId);
        userRoleService.insertUserRole(userRole);

        return true;
    }

    @Override
    public SessionDto login(String username, String password) {

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        Subject subject = SecurityUtils.getSubject();
        subject.login(new UsernamePasswordToken(user.getUsername(), user.getPassword()));

        String sessionId = (String)subject.getSession().getId();

        SessionDto sessionDto = new SessionDto();
        sessionDto.setSessionId(sessionId);
        return sessionDto;
    }

    @Override
    public List<UserInfo> getAllUsers() {
        return userInfoService.getAllUserInfo();
    }

    @Override
    public UserInfo getUserinfoByUsername(String username) throws Exception {
        return userInfoService.getUserinfoByUsername(username);
    }

    @Override
    @Transactional(rollbackFor=Exception.class) //默认情况下，Transactional只捕获RuntimeException，加特定注解时，普通异常也可以回滚
    public boolean identificateUser(Map<String, String> params) throws Exception{
        String activeCodeStr = params.get("activeCode");
        String realName = params.get("realName");
        String hwid = params.get("hwid");
        String verifyCode = params.get("verifyCode");
        if(StringUtils.isBlank(activeCodeStr) || StringUtils.isBlank(realName) || StringUtils.isBlank(hwid) || StringUtils.isBlank(verifyCode)) {
            throw new InvalidParamException();
        }
        //先较验verifyCode
        if (!CommonUtil.checkVerifyCode(activeCodeStr, hwid, verifyCode)) {
            throw new ActiveCodeVerifyException();
        }

        //较验激活码
        ActiveCode activeCode = activeCodeService.getActiveCodeByString(activeCodeStr);
        long activeCodeId = activeCode.getId();

        //将激活设置为已使用状态
        activeCode.setStatus(ActiveCodeStatusEnum.INVAILD.getCode());
        activeCodeService.updateActiveCode(activeCode);

        Subject currentUser = SecurityUtils.getSubject();
        User user = (User)currentUser.getPrincipal();

        //将用户未认证状态更新为已认证状态
        UserRoleExample example = new UserRoleExample();
        example.createCriteria().andUserIdEqualTo(user.getId()).andRoleIdEqualTo(RoleIdEnum.UNAUTH.getRoleId());
        List<UserRole> userRoles = userRoleService.getUserRoleByExample(example);
        if (userRoles.size() != 1) {
            throw new SystemCommonException();
        }
        UserRole userRole = userRoles.get(0);
        userRole.setRoleId(RoleIdEnum.PRIMARY.getRoleId());
        userRoleService.updateUserRole(userRole);

        //将用户置为激活状态
        user.setActive(UserStatusEnum.ACTIVE.getCode());
        userService.updateUser(user);

        //获取用户detailId
        long detailId = userDetailService.getDetailIdByUserId(user.getId());

        UserDetail userDetail = new UserDetail();
        userDetail.setId(detailId);
        userDetail.setHwid(hwid);
        userDetail.setActiveCodeId(activeCodeId);
        userDetail.setRealName(realName);
        userDetail.setActiveDate(new Date());
        // endDate默认为一年
        Calendar curr = Calendar.getInstance();
        curr.set(Calendar.YEAR,curr.get(Calendar.YEAR)+1);
        userDetail.setEndDate(curr.getTime());

        userDetailService.updateUserDetail(userDetail);

        return true;
    }
}
