import com.hewuqi.commons.enums.ActiveCodeStatusEnum;
import com.hewuqi.commons.utils.IdWorker;
import com.hewuqi.shiro.ShiroApplication;
import com.hewuqi.shiro.model.ActiveCode;
import com.hewuqi.shiro.service.ActiveCodeService;
import com.hewuqi.shiro.util.ActiveCodeUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

/**
 * @author https://github.com/yaphone
 * @version 1.0
 * @date 2018/11/4 22:49
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes={ShiroApplication.class})// 指定启动类
public class ApplicationTest {

    private static IdWorker idWorker = new IdWorker(0, 0);

    @Autowired
    private ActiveCodeService activeCodeService;

    @Test
    public void generateActiveCode() {
        for(int i = 0; i < 10; i ++) {
            ActiveCode activeCode = new ActiveCode();
            activeCode.setId(idWorker.nextId());
            activeCode.setActiveCode(ActiveCodeUtil.generateActiveCode());
            activeCode.setGenerateTime(new Date());
            activeCode.setStatus(ActiveCodeStatusEnum.AVAILD.getCode());

            activeCodeService.insertActiveCode(activeCode);
        }
    }
}
